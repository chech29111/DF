import React from 'react';
import FormPage from './pages/FormPage';

function App() {
  return <FormPage/>;
}

export default App;
