import React from 'react';
import { LINES_COLOR } from '../../consts';

export default () => <hr style={{ borderColor: LINES_COLOR }} />;
