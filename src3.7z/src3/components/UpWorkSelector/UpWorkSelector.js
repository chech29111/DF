import React, {useContext, useEffect, useState} from 'react';
import StyledReactSelect from '../StyledReactSelect/StyledReactSelect';
import WorkTable from '../WorkTable/WorkTable';
import TypeContext from "../../context";
import {getData, getItem} from "../../helpers/helpers";
import DivisionSelector from "../DivisionSelector/DivisionSelector";

function WorkSelector({
                          divisions, initialValue, disabled, namePrefix,DivisionNamePrefix
                      }) {

    const initialWorks = initialValue && initialValue.divisions ? initialValue.divisions : [];
    const [selectedWorks, changeSelectedWorks] = useState(
        initialWorks.length > 0 ? initialWorks : [],
    );

    const type = useContext(TypeContext);
    const isDisplayForm = type === 'disp';
    const isEditForm = type === 'edit';
    const isNewForm = type === 'new';

    const [state, setState] = useState({
        divisions: [],
        updivisions: [],
        selectedDivisions: [],
        selectedUpDivisions: [],
        itemData: {
            divisions: [],
            updivisions: [],
        },
        itemUpData: {
            divisions: [],
            updivisions: [],
        },
    });

    // аналог componentDidMount - получаем данные.
    // обновляем стэйт.
    // Зависимость от изменения значения переменной type;
    useEffect(() => {
        if (isNewForm) {
            getData().then((data) => {
                setState((currentState) => ({
                    ...currentState,
                    divisions: [...data.divisions],
                    updivisions: [...data.updivisions]
                }));
            });

        } else if (isEditForm || isDisplayForm) {
            Promise.all([getData(), getItem()]).then((data) => {
                    const itemDivisions = selectedWorks;
                    setState((currentState) => ({
                        ...currentState,
                        divisions: [...data[0].divisions],
                        selectedDivisions: itemDivisions,
                        itemData: itemDivisions,
                    }));
                }
            );
        }
    }, [isDisplayForm, isEditForm, isNewForm, type]);



//console.log('state.selectedDivisions',state.selectedDivisions)








    // const pickWorkHandler = (option) => {
    //     changeSelectedWorks([...selectedWorks, option]);
    // };

    const pickWorkHandler = (option) => {
        changeSelectedWorks([...selectedWorks, option]);
        setState((currentState) => {
                return {
                    ...currentState,
                    selectedDivisions: [...currentState.selectedDivisions, option],
                }
            }
        );
    };
    const removeWorkHandler = (id) => {
        const newSelectedWorks = id === null
            ? []
            : selectedWorks.filter((work) => Number(work.id) !== Number(id));
        changeSelectedWorks(newSelectedWorks);
    };

    const changeWorks = (selectedValues, evtData) => {
        const { action } = evtData;
        let option;

        switch (action) {
            case 'select-option':
                option = evtData.option;
                pickWorkHandler(option);
                break;
            case 'remove-value':
            case 'pop-value':
                option = evtData.removedValue;
                removeWorkHandler(option.id);
                break;
            case 'clear':
                removeWorkHandler(null);
                break;
            default:
                throw new Error('Unhandled react select action type.');
        }
    };

    const removeWork = (id) => {
        changeSelectedWorks([...selectedWorks.filter((work) => Number(work.id) !== Number(id))]);
    };




   // console.log(state.selectedDivisions)

    // Генерация контейнеров с выбором разделов
    const divisionSelectorsConts = state.selectedDivisions.map((selectorDivision) => {
      const division = state.divisions.find((item) => item.id === selectorDivision.id);
      const { id, title } = division;
      let { works } = division;
      const initialValue = isDisplayForm || isEditForm
        ? state.itemData.find((item) => item.id === selectorDivision.id)
        : null;
      const namePrefix = `division-${id}`;
      if (initialValue) {
        // Если есть начальное значение, значит это форма просмотра\редактирования. Значит:
        // мержим работы между уже выбранными в ведомости и оставшимися не выбранными,
        // чтобы предотвратить коллизию айдишников и
        // позволить выбрать(добавить) ранее не выбранные работы.
        const notSelectedWorks = works.filter((work) => {
          const idx = initialValue.works.findIndex((initWork) => Number(initWork.id) === Number(work.id));
          return idx === -1;
        });
        works = [...notSelectedWorks, ...initialValue.works];
      }
      return <DivisionSelector
          removeWorkHandler={removeWorkHandler}
        title={title}
        divisionId={id}
        key={id}
        works={works}
        initialValue={initialValue}
        namePrefix={namePrefix}
        disabled={isDisplayForm}
      />;
    });

    const getOptionLabel = (option) => option.title;
    const getOptionValue = (option) => option.id;

    return (
        <>
            <StyledReactSelect
                asHeader
                options={state.divisions}
                value={selectedWorks}
                isMulti
                getOptionLabel={getOptionLabel}
                getOptionValue={getOptionValue}
                onChange={changeWorks}
                isDisabled={disabled}
                placeholder="Начните ввод или выберите мышкой..."
                noOptionsMessage={() => <span>Доступных для выбора работ нет.</span>}
            />
            {divisionSelectorsConts}
            {/*<WorkTable*/}
            {/*    works={selectedWorks}*/}
            {/*    disabled={disabled}*/}
            {/*    removeHandler={removeWork}*/}
            {/*    namePrefix={namePrefix}*/}
            {/*    DivisionNamePrefix={DivisionNamePrefix}*/}
            {/*/>*/}
        </>
    );
}

export default WorkSelector;
